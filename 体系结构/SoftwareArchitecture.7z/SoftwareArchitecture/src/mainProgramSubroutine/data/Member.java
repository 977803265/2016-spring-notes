package mainProgramSubroutine.data;

/**
 * Created by Nifury on 2/19/2016.
 */
public class Member {
    public int id;
    public Object info;
}
