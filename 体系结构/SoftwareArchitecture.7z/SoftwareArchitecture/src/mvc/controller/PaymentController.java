package mvc.controller;

/**
 * Created by Nifury on 2/26/2016.
 */
public class PaymentController {
    public double getPayment() {
        return 100.0;
    }
}
