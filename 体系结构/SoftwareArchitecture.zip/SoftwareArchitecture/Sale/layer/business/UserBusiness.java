package layer.business;

import layer.data.Member;

/**
 * Created by troyeagle on 2/26/2016.
 */
public class UserBusiness {
    public Member getMember() {
        return new Member();
    }

    public void update() {

    }
}
