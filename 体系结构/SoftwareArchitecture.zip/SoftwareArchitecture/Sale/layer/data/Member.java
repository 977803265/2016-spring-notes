package layer.data;

/**
 * Created by troyeagle on 2/26/2016.
 */
public class Member {
    private int id;
    private Object info;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Object getInfo() {
        return info;
    }

    public void setInfo(Object info) {
        this.info = info;
    }
}
