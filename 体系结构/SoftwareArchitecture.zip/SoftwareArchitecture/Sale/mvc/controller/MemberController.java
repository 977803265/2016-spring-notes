package mvc.controller;

import mvc.model.Member;

/**
 * Created by troyeagle on 2/21/2016.
 */
public class MemberController {
    public Member getMember() {
        return new Member();
    }

    public void update() {

    }
}
