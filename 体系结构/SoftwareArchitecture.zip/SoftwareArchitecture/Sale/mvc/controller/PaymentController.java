package mvc.controller;

/**
 * Created by troyeagle on 2/26/2016.
 */
public class PaymentController {
    public double getPayment() {
        return 100.0;
    }
}
