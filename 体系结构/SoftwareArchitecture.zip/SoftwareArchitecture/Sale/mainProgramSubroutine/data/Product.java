package mainProgramSubroutine.data;

/**
 * Created by troyeagle on 2/19/2016.
 */
public class Product {
    public int id;
    public int price;
    public int stock;
}
